export function ThemeToggle() {
  // Theme toggle has been removed
  return null;
}
